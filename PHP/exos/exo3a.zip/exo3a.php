<?php
    $modulo = 8%5;
    echo "Le reste de la divion 8 / 5 est ",$modulo;
?>

<?php
    $actuel = 377;
    $precedent = 233;
    echo "Dans 0,1,1,2,3,5,8,13,21,34,55,89,144,233,377 sa suite est ", $actuel + $precedent ;
?>

<?php
    $a = 33;
    $b = 53;
    $x = 27;

    $result = ($x * $b) / $a;

    echo "27 vaut ", $result;
?>

<?php
    $a = 8;
    $a += 5;
    echo "Lorsque j'incrémente 5 à la valeur 8 on obtiens ", $a;
?>

<?php
    $x = 50.265482;
    $pi = $x / 16;

    echo $pi;
?>