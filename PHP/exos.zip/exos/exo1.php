<?php
$nom = "Denis";
?>