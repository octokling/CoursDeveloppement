<?php
$nom1 = "Gaillard";
echo "Nom : ", $nom1, "\n";
$prenom1 = "Logan";
echo "Prénom : ", $prenom1, "\n";
$adresse1 = "10 rue des fougères";
echo "Adresse : ", $adresse1, "\n";
$email1 = "logangaillard@outlook.fr";
echo "Email : ", $email1, "\n";
?>