<?php
$x = "Hello world!";
$y = 'Bonjour tout le monde!';
echo $x;
echo "<br>";
echo $y;
?>

<?php
echo strlen("Salut tout le monde !");
?>

<?php
echo str_word_count("Comment allez-vous ?");
?>
<?php
echo strrev("Je suis a l'envers");
?>

<?php
echo strpos("Je vais bien", "tres");
echo strpos("Je vais bien", "vais");
?>

<?php
echo str_replace("e", "x", "Tout les E sont remplace par les x");
?>

<?php
$x = 268;
var_dump($x);
?>

<?php
$x = 61.875;
var_dump($x);
?>

<?php 
$x = TRUE;
$y = FALSE;
var_dump($x);
echo "<br>";
var_dump($y);
?> 